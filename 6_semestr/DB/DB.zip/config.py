host = '127.0.0.1'
user = 'postgres'
password = 'Rp11m358ba'
db_name = 'main_sklad'
db_port = 5050